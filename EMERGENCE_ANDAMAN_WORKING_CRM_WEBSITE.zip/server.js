const express=require("express");
const path=require("path");
require("dotenv").config();
const app=express();
app.use(express.json({limit:"50kb"}));
app.use(express.static(path.join(__dirname,"public")));

const PORT=process.env.PORT||3000;
const need=n=>{if(!process.env[n])throw new Error("Missing environment variable: "+n);return process.env[n]};

app.post("/api/enquiry",async(req,res)=>{
 try{
  const d=req.body||{};
  if(!String(d.name||"").trim()||!String(d.phone||"").trim()) return res.status(400).json({ok:false,error:"Name and phone are required."});
  const enquiryId="EA-"+Date.now().toString(36).toUpperCase();

  const fields={
   "Enquiry ID":enquiryId,"Customer Name":d.name||"","Phone / WhatsApp":d.phone||"","Email":d.email||"",
   "Travel Start":d.travelStart||"","Travel End":d.travelEnd||"","Adults":Number(d.adults||0),"Children":Number(d.children||0),
   "Package":d.package||"","Destination":d.destination||"","Hotel Preference":d.hotel||"","Budget":d.budget||"",
   "Pickup / Drop":d.pickupDrop||"","Special Requests":d.message||"","Lead Status":"New","Booking Status":"Enquiry",
   "Created At":new Date().toISOString()
  };

  const at=await fetch(`https://api.airtable.com/v0/${need("AIRTABLE_BASE_ID")}/${encodeURIComponent(process.env.AIRTABLE_TABLE_NAME||"Enquiries")}`,{
   method:"POST",headers:{"Authorization":`Bearer ${need("AIRTABLE_TOKEN")}`,"Content-Type":"application/json"},body:JSON.stringify({fields})
  });
  if(!at.ok)return res.status(502).json({ok:false,error:"Airtable submission failed.",details:await at.text()});

  const hh={"Authorization":`Bearer ${need("HUBSPOT_ACCESS_TOKEN")}`,"Content-Type":"application/json"};
  let contactId=null;
  if(d.email){
   const s=await fetch("https://api.hubapi.com/crm/v3/objects/contacts/search",{method:"POST",headers:hh,
    body:JSON.stringify({filterGroups:[{filters:[{propertyName:"email",operator:"EQ",value:d.email}]}],properties:["firstname","email","phone"],limit:1})});
   if(s.ok){const j=await s.json();contactId=j.results?.[0]?.id||null;}
  }
  if(contactId){
   await fetch(`https://api.hubapi.com/crm/v3/objects/contacts/${contactId}`,{method:"PATCH",headers:hh,body:JSON.stringify({properties:{firstname:d.name||"",phone:d.phone||""}})});
  }else{
   const c=await fetch("https://api.hubapi.com/crm/v3/objects/contacts",{method:"POST",headers:hh,body:JSON.stringify({properties:{firstname:d.name||"",phone:d.phone||"",email:d.email||""}})});
   if(c.ok){const j=await c.json();contactId=j.id||null;}
  }
  res.json({ok:true,enquiryId,hubspotContactId:contactId});
 }catch(e){res.status(500).json({ok:false,error:e.message});}
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`EMERGENCE ANDAMAN: http://localhost:${PORT}`));
