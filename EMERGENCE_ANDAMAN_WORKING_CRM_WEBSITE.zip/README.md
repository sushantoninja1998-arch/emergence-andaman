# EMERGENCE ANDAMAN — Working CRM Website

Run:
1. Install Node.js 18+.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Add Airtable and HubSpot secrets to `.env`.
5. Run `npm start`.
6. Open http://localhost:3000

The browser never receives the CRM secrets. Enquiries go to the server endpoint `/api/enquiry`, then to Airtable and HubSpot. After a successful submission, WhatsApp opens with the enquiry details.

The existing Airtable base/table used by this project:
Base: EMERGENCE ANDAMAN CRM
Base ID: app0whkuazzF2Hmsn
Table: Enquiries

HubSpot deal creation is intentionally not automated yet because the exact sales pipeline/stage must be selected first.
